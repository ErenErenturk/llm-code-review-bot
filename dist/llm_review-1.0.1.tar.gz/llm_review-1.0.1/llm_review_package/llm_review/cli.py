from llm_review_package.llm_review.review_folder import main as run_review

def main():
    run_review()
